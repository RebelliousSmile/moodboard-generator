<?php

// Tokens — à définir en variables d'environnement ou en dur pour le bootstrap
define('READ_TOKEN',  getenv('RATING_READ_TOKEN')  ?: '');
define('WRITE_TOKEN', getenv('RATING_WRITE_TOKEN') ?: 'changeme');

// Chemin du fichier de données
define('DATA_FILE', __DIR__ . '/data/sources.json');

// Score minimum pour apparaître dans les résultats
define('MIN_SCORE', 0.1);

// Nombre max de sources retournées par défaut
define('DEFAULT_LIMIT', 20);
