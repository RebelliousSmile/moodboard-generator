<?php
declare(strict_types=1);

/**
 * Charge le store depuis le fichier JSON.
 * Crée le fichier avec le seed si absent.
 */
function loadStore(): array {
    if (!file_exists(DATA_FILE)) {
        $seed = getSeed();
        file_put_contents(DATA_FILE, json_encode($seed, JSON_UNESCAPED_UNICODE | JSON_PRETTY_PRINT));
        return $seed;
    }

    $raw = file_get_contents(DATA_FILE);
    $data = json_decode($raw, true);

    if (!$data || !isset($data['domains'])) {
        return getSeed();
    }

    return $data;
}

/**
 * Sauvegarde le store dans le fichier JSON.
 */
function saveStore(array $store): void {
    $store['updated_at'] = date('c');

    $dir = dirname(DATA_FILE);
    if (!is_dir($dir)) {
        mkdir($dir, 0755, true);
    }

    // Écriture atomique
    $tmp = DATA_FILE . '.tmp';
    file_put_contents($tmp, json_encode($store, JSON_UNESCAPED_UNICODE | JSON_PRETTY_PRINT));
    rename($tmp, DATA_FILE);
}

/**
 * Enregistre un feedback et recalcule le score.
 */
function recordFeedback(array $store, array $feedback): array {
    $domain = $feedback['domain'];
    $usage  = $feedback['usage'];

    // Initialiser le domaine s'il n'existe pas
    if (!isset($store['domains'][$domain])) {
        $store['domains'][$domain] = [
            'usages'       => [],
            'tier'         => $feedback['tier'] ?? 2,
            'hotlink_safe' => $feedback['hotlink_safe'] ?? true,
            'notes'        => $feedback['notes'] ?? '',
        ];
    }

    $entry = &$store['domains'][$domain];

    // Mettre à jour les métadonnées si fournies
    if ($feedback['tier'] !== null) {
        $entry['tier'] = (int)$feedback['tier'];
    }
    if ($feedback['hotlink_safe'] !== null) {
        $entry['hotlink_safe'] = (bool)$feedback['hotlink_safe'];
    }
    if ($feedback['notes'] !== null) {
        $entry['notes'] = $feedback['notes'];
    }

    // Initialiser les stats pour cet usage
    if (!isset($entry['usages'][$usage])) {
        $entry['usages'][$usage] = [
            'succes'  => 0,
            'echecs'  => 0,
            'score'   => 0.5,
            'raisons' => [],
        ];
    }

    $stats = &$entry['usages'][$usage];

    if ($feedback['success']) {
        $stats['succes']++;
    } else {
        $stats['echecs']++;
        if ($feedback['reason']) {
            $stats['raisons'][] = $feedback['reason'];
            // Garder les 10 dernières raisons max
            $stats['raisons'] = array_slice($stats['raisons'], -10);
        }
    }

    // Recalculer le score : Wilson score interval (borne basse)
    $stats['score'] = wilsonScore($stats['succes'], $stats['echecs']);

    return $store;
}

/**
 * Classe les sources pour un usage donné.
 */
function rankSources(array $store, string $usage, int $limit): array {
    $results = [];

    foreach ($store['domains'] as $domain => $entry) {
        if (!isset($entry['usages'][$usage])) {
            continue;
        }

        $stats = $entry['usages'][$usage];
        if ($stats['score'] < MIN_SCORE) {
            continue;
        }

        $results[] = [
            'domain'       => $domain,
            'tier'         => $entry['tier'] ?? 2,
            'hotlink_safe' => $entry['hotlink_safe'] ?? true,
            'score'        => round($stats['score'], 3),
            'succes'       => $stats['succes'],
            'echecs'       => $stats['echecs'],
            'notes'        => $entry['notes'] ?? '',
        ];
    }

    // Tri : tier ASC, score DESC
    usort($results, function ($a, $b) {
        if ($a['tier'] !== $b['tier']) {
            return $a['tier'] <=> $b['tier'];
        }
        return $b['score'] <=> $a['score'];
    });

    return array_slice($results, 0, $limit);
}

/**
 * Wilson score interval (borne basse, z=1.96 pour 95% de confiance).
 * Donne un score conservateur qui favorise les domaines avec beaucoup
 * de données ET un bon taux de succès.
 */
function wilsonScore(int $succes, int $echecs): float {
    $n = $succes + $echecs;
    if ($n === 0) {
        return 0.5;
    }

    $z = 1.96;
    $p = $succes / $n;

    $numerator = $p + ($z * $z) / (2 * $n) - $z * sqrt(($p * (1 - $p) + ($z * $z) / (4 * $n)) / $n);
    $denominator = 1 + ($z * $z) / $n;

    return max(0, $numerator / $denominator);
}

/**
 * Seed initial — les sources connues avec données de départ.
 */
function getSeed(): array {
    return [
        'updated_at' => date('c'),
        'domains' => [
            // TIER 1 — Institutionnels
            'nagasaki-tabinet.com' => [
                'tier' => 1,
                'hotlink_safe' => true,
                'notes' => 'Office du tourisme de Nagasaki, images HD libres',
                'usages' => [
                    'voyage' => ['succes' => 5, 'echecs' => 0, 'score' => 0.72, 'raisons' => []],
                ],
            ],
            'japan.travel' => [
                'tier' => 1,
                'hotlink_safe' => true,
                'notes' => 'JNTO, images officielles Japon',
                'usages' => [
                    'voyage' => ['succes' => 3, 'echecs' => 1, 'score' => 0.44, 'raisons' => ['403_on_direct']],
                ],
            ],
            'france.fr' => [
                'tier' => 1,
                'hotlink_safe' => false,
                'notes' => 'Atout France, hotlink bloqué',
                'usages' => [
                    'voyage' => ['succes' => 2, 'echecs' => 3, 'score' => 0.12, 'raisons' => ['hotlink_blocked', 'cors', 'cors']],
                ],
            ],

            // TIER 2 — Blogs spécialisés
            'voyapon.com' => [
                'tier' => 2,
                'hotlink_safe' => true,
                'notes' => 'CDN S3 public, pas de hotlink check, images Japon',
                'usages' => [
                    'voyage' => ['succes' => 12, 'echecs' => 0, 'score' => 0.88, 'raisons' => []],
                ],
            ],
            'encirclephotos.com' => [
                'tier' => 2,
                'hotlink_safe' => true,
                'notes' => 'Photographies monde entier, HD, accès direct',
                'usages' => [
                    'voyage' => ['succes' => 8, 'echecs' => 1, 'score' => 0.71, 'raisons' => []],
                ],
            ],

            // TIER 3 — APIs publiques
            'upload.wikimedia.org' => [
                'tier' => 3,
                'hotlink_safe' => false,
                'notes' => 'Domaine public, utiliser API wikimedia (pas en hotlink direct)',
                'usages' => [
                    'voyage' => ['succes' => 10, 'echecs' => 2, 'score' => 0.67, 'raisons' => ['hotlink_blocked', 'resolution_low']],
                    'fiction' => ['succes' => 6, 'echecs' => 1, 'score' => 0.56, 'raisons' => []],
                    'jeu_de_role' => ['succes' => 4, 'echecs' => 0, 'score' => 0.56, 'raisons' => []],
                ],
            ],
            'api.europeana.eu' => [
                'tier' => 3,
                'hotlink_safe' => true,
                'notes' => 'Archives européennes, art, histoire — clé API gratuite',
                'usages' => [
                    'fiction' => ['succes' => 4, 'echecs' => 0, 'score' => 0.56, 'raisons' => []],
                    'illustration' => ['succes' => 3, 'echecs' => 0, 'score' => 0.44, 'raisons' => []],
                ],
            ],
            'collectionapi.metmuseum.org' => [
                'tier' => 3,
                'hotlink_safe' => true,
                'notes' => 'Met Museum, 400k œuvres domaine public, sans clé',
                'usages' => [
                    'illustration' => ['succes' => 5, 'echecs' => 0, 'score' => 0.63, 'raisons' => []],
                    'decoration' => ['succes' => 3, 'echecs' => 0, 'score' => 0.44, 'raisons' => []],
                ],
            ],
            'api.artic.edu' => [
                'tier' => 3,
                'hotlink_safe' => true,
                'notes' => 'Art Institute of Chicago, sans clé',
                'usages' => [
                    'illustration' => ['succes' => 4, 'echecs' => 0, 'score' => 0.56, 'raisons' => []],
                ],
            ],
        ],
    ];
}
