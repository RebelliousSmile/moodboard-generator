<?php
declare(strict_types=1);

require_once __DIR__ . '/config.php';
require_once __DIR__ . '/store.php';

header('Content-Type: application/json; charset=utf-8');

// Preflight CORS
if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') {
    http_response_code(204);
    exit;
}

// Simple routing
$path = trim(parse_url($_SERVER['REQUEST_URI'], PHP_URL_PATH), '/');
$method = $_SERVER['REQUEST_METHOD'];

// Auth helper
function requireToken(string $level): void {
    $header = $_SERVER['HTTP_AUTHORIZATION'] ?? '';
    $token = str_starts_with($header, 'Bearer ') ? substr($header, 7) : '';

    if ($level === 'read' && READ_TOKEN !== '' && $token !== READ_TOKEN) {
        http_response_code(401);
        echo json_encode(['error' => 'Token de lecture requis']);
        exit;
    }
    if ($level === 'write' && $token !== WRITE_TOKEN) {
        http_response_code(401);
        echo json_encode(['error' => 'Token d\'écriture requis']);
        exit;
    }
}

function jsonResponse(mixed $data, int $code = 200): void {
    http_response_code($code);
    echo json_encode($data, JSON_UNESCAPED_UNICODE | JSON_PRETTY_PRINT);
    exit;
}

function jsonError(string $msg, int $code = 400): void {
    jsonResponse(['error' => $msg], $code);
}

// ── Routes ──

// GET /sources?usage=voyage&limit=10
if ($path === 'sources' && $method === 'GET') {
    requireToken('read');

    $usage = $_GET['usage'] ?? null;
    $limit = (int)($_GET['limit'] ?? DEFAULT_LIMIT);

    if (!$usage) {
        jsonError('Paramètre "usage" requis.');
    }

    $store = loadStore();
    $ranked = rankSources($store, $usage, $limit);
    jsonResponse([
        'usage' => $usage,
        'count' => count($ranked),
        'sources' => $ranked,
    ]);
}

// GET /sources/domain?domain=voyapon.com
if ($path === 'sources/domain' && $method === 'GET') {
    requireToken('read');

    $domain = $_GET['domain'] ?? null;
    if (!$domain) {
        jsonError('Paramètre "domain" requis.');
    }

    $store = loadStore();
    $entry = $store['domains'][$domain] ?? null;

    if (!$entry) {
        jsonError("Domaine \"$domain\" inconnu.", 404);
    }

    jsonResponse(['domain' => $domain, ...$entry]);
}

// POST /feedback
if ($path === 'feedback' && $method === 'POST') {
    requireToken('write');

    $body = json_decode(file_get_contents('php://input'), true);
    if (!$body) {
        jsonError('Corps JSON requis.');
    }

    $domain  = $body['domain'] ?? null;
    $usage   = $body['usage'] ?? null;
    $success = $body['success'] ?? null;

    if (!$domain || !$usage || $success === null) {
        jsonError('Champs requis : domain, usage, success.');
    }

    $reason      = $body['reason'] ?? null;
    $tier        = $body['tier'] ?? null;
    $hotlinkSafe = $body['hotlink_safe'] ?? null;
    $notes       = $body['notes'] ?? null;

    $store = loadStore();
    $store = recordFeedback($store, [
        'domain'       => $domain,
        'usage'        => $usage,
        'success'      => (bool)$success,
        'reason'       => $reason,
        'tier'         => $tier,
        'hotlink_safe' => $hotlinkSafe,
        'notes'        => $notes,
    ]);
    saveStore($store);

    $entry = $store['domains'][$domain];
    jsonResponse([
        'ok' => true,
        'domain' => $domain,
        'usage_stats' => $entry['usages'][$usage] ?? null,
    ]);
}

// GET /stats
if ($path === 'stats' && $method === 'GET') {
    requireToken('read');

    $store = loadStore();
    $domainCount = count($store['domains']);
    $totalFeedback = 0;
    foreach ($store['domains'] as $d) {
        foreach ($d['usages'] as $u) {
            $totalFeedback += $u['succes'] + $u['echecs'];
        }
    }

    jsonResponse([
        'domains' => $domainCount,
        'feedbacks' => $totalFeedback,
        'updated_at' => $store['updated_at'] ?? null,
    ]);
}

// 404
jsonError("Route inconnue : $method /$path", 404);
